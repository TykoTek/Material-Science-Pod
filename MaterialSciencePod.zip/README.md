# Material-Science-Pod
MSP-3000 Material Science Pod

Requires ModuleManager

INSTALL:
Drop the contents of GameData folder into your KSP/GameData folder

Models by Ven from Ven's Stock Revamp used under CC-BY 4.0 International
